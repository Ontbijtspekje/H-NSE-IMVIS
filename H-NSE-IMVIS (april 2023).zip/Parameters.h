#pragma once
#define LEVELS 256 // aantal grijswaarden
